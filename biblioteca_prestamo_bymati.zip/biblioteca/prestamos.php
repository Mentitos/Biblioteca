<!DOCTYPE html>
<head>
<meta charset="UTF-8">
<title>PRÉSTAMOS</title>
</head>

<body>
<?php
    include("formatos.php");
    grilla_header();
    ?>
<div class="content">
    <a class="btn-menu" href="nuevo.php">Nuevo préstamo <span class="mas">+</span></a>
    <a class="btn-menu" href="devolucion.php">devolución <span class="menos">-</span></a>
    <a class="btn-menu" href="historial_prestamos.php">Historial de préstamos</a>
</div>
</body>
</html>